module.exports = {
    ipcim:'http://mezo-tamas-zsolt-back.dszcbaross.tk/'
};